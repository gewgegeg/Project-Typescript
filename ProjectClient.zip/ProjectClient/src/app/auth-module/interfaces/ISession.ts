export interface ISession {
    expireAt: string,
    token: string
}