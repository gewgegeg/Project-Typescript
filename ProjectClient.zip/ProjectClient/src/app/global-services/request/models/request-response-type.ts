export enum RequestResponseType {
    arrayBuffer = 'arraybuffer',
    blob = 'blob',
    json = 'json',
    text = 'text'
}