export enum UrlRoutes {
    device = 'https://localhost:44393'
}