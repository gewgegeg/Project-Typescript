import { TestBed } from '@angular/core/testing';

import { DeviceStateService } from './device-state.service';

describe('DeviceStateService', () => {
    let service: DeviceStateService;

    beforeEach(() => {
        TestBed.configureTestingModule({});
        service = TestBed.inject(DeviceStateService);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });
});
