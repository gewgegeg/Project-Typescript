import { TestBed } from '@angular/core/testing';

import { DeviceInfoService } from './device-info.service';

describe('DeviceInfoService', () => {
    let service: DeviceInfoService;

    beforeEach(() => {
        TestBed.configureTestingModule({});
        service = TestBed.inject(DeviceInfoService);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });
});
