import { DeviceScreen } from '../deviceScreen';

export class DeviceScreenResponse {
    public readonly base64ScreenFrame?: string;
}