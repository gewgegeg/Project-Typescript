export enum DeviceStatus {
    enabled,
    disabled,
    sleep,
    blocked
}